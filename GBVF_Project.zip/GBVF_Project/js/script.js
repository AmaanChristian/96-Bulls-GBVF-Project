let originalTextsLoaded = false;

function loadOriginalTexts() {
    if (originalTextsLoaded) return;
    document.querySelectorAll('[data-translate]').forEach(element => {
        const key = element.getAttribute('data-translate');
        if (element.innerText !== undefined && element.innerText.trim() !== '') {
            translations[key] = element.innerText;
        } else if (element.hasAttribute('placeholder')) {
            translations[key] = element.getAttribute('placeholder');
        } else if (element.hasAttribute('title')) {
            translations[key] = element.getAttribute('title');
        }
    });
    originalTextsLoaded = true;
}

async function translatePage() {
    const languageSelect = document.getElementById("languageSelect");

    if (!languageSelect) {
        console.warn("Element with ID 'languageSelect' not found. Translation functionality may not work as expected.");
        return;
    }

    const targetLang = languageSelect.value;

    if (targetLang === 'en') {
        document.querySelectorAll('[data-translate]').forEach(element => {
            const key = element.getAttribute('data-translate');
            if (translations[key]) {
                if (element.innerText !== undefined) {
                    element.innerText = translations[key];
                } else if (element.hasAttribute('placeholder')) {
                    element.setAttribute('placeholder', translations[key]);
                } else if (element.hasAttribute('title')) {
                    element.setAttribute('title', translations[key]);
                }
            }
        });
        console.log("Page restored to English.");
        return;
    }

    const elementsToTranslate = document.querySelectorAll('[data-translate]');
    const translatePromises = [];

    elementsToTranslate.forEach(element => {
        const key = element.getAttribute('data-translate');
        const originalText = translations[key] || element.innerText;

        if (originalText.trim() === "") {
            console.log(`Element with data-translate='${key}' is empty, skipping translation.`);
            return;
        }

        const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=${targetLang}&dt=t&q=${encodeURIComponent(originalText)}`;

        translatePromises.push(
            fetch(url)
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.json();
                })
                .then(data => {
                    if (data && data[0] && data[0][0] && data[0][0][0]) {
                        const translatedText = data[0][0][0];
                        if (element.innerText !== undefined) {
                            element.innerText = translatedText;
                        } else if (element.hasAttribute('placeholder')) {
                            element.setAttribute('placeholder', translatedText);
                        } else if (element.hasAttribute('title')) {
                            element.setAttribute('title', translatedText);
                        }
                    } else {
                        console.warn(`No valid translation found for key '${key}'.`);
                    }
                })
                .catch(error => console.error(`Translation error for key '${key}':`, error))
        );
    });

    await Promise.allSettled(translatePromises);
    console.log(`All elements processed for translation to ${targetLang}.`);
}

document.addEventListener("DOMContentLoaded", function () {
    const profileIcon = document.getElementById("profileIcon");
    const emergencyBtn = document.getElementById("emergencyBtn");
    const storyButton = document.getElementById("Story");
    const learnButton = document.getElementById("Learn");
    const header = document.querySelector('header');
    const backgroundImage = document.querySelector('.background-image img');
    const profileModal = document.getElementById('profileModal');
    const modalMessage = document.getElementById('modalMessage');
    const modalYes = document.getElementById('modalYes');
    const modalNo = document.getElementById('modalNo');
    const emergencyDiv = document.getElementById('emergencyDiv');
    const emergencyPopup = document.getElementById('emergencyPopup');
    const confirmEmergencyBtn = document.getElementById('confirmEmergencyBtn');
    const cancelEmergencyBtn = document.getElementById('cancelEmergencyBtn');
    const callEmergencyBtn = document.getElementById('callEmergency');
    const smsEmergencyBtn = document.getElementById('smsEmergency');
    const silentAlarmBtn = document.getElementById('silentAlarm');
    const closePopupBtn = emergencyPopup.querySelector('.close-btn');

    loadOriginalTexts();

    if (emergencyBtn) {
        emergencyBtn.addEventListener("click", function() {
            showEmergencyPopup();
        });
    }

    if (emergencyDiv) {
        emergencyDiv.addEventListener('click', showEmergencyPopup);
    }

    function showEmergencyPopup() {
        emergencyPopup.style.display = 'block';
        emergencyPopup.querySelector('.confirmation-buttons').style.display = 'block';
        emergencyPopup.querySelector('.options').style.display = 'none';
    }

    if (confirmEmergencyBtn) {
        confirmEmergencyBtn.addEventListener('click', function() {
            emergencyPopup.querySelector('.confirmation-buttons').style.display = 'none';
            emergencyPopup.querySelector('.options').style.display = 'block';
        });
    }

    if (cancelEmergencyBtn) {
        cancelEmergencyBtn.addEventListener('click', function() {
            emergencyPopup.style.display = 'none';
        });
    }

    if (callEmergencyBtn) {
        callEmergencyBtn.addEventListener('click', function() {
            window.location.href = 'tel:10111';
            emergencyPopup.style.display = 'none';
        });
    }

    if (smsEmergencyBtn) {
        smsEmergencyBtn.addEventListener('click', function () {
            let smsBody = "Emergency! I need urgent help. Please send assistance.";
            const phoneNumber = "0800428428";

            function sendSMS(body) {
                const smsURI = `sms:${phoneNumber}?body=${encodeURIComponent(body)}`;
                window.location.href = smsURI;
            }

            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    function (position) {
                        const lat = position.coords.latitude;
                        const lon = position.coords.longitude;
                        smsBody += ` My approximate location is: https://www.google.com/maps?q=$${lat},${lon}`;
                        sendSMS(smsBody);
                    },
                    function (error) {
                        console.error("Error getting location: ", error);
                        alert("Could not get your location for the SMS. Please add it manually if possible.");
                        sendSMS(smsBody);
                    }
                );
            } else {
                alert("Geolocation is not supported by your browser. Please add your location manually if possible.");
                sendSMS(smsBody);
            }
            emergencyPopup.style.display = 'none';
        });
    }

    if (silentAlarmBtn) {
        silentAlarmBtn.addEventListener('click', function() {
            alert('Silent alarm activated! Discreet notification sent to your pre-configured contacts (simulated).');
            console.log('Silent alarm triggered. In a real system, this would send a background alert to emergency contacts.');
            emergencyPopup.style.display = 'none';
        });
    }

    if (closePopupBtn) {
        closePopupBtn.addEventListener('click', function() {
            emergencyPopup.style.display = 'none';
        });
    }

    if (storyButton) {
        storyButton.addEventListener("click", function() {
            window.location.href = "legal.html";
        });
    }

    if (learnButton) {
        learnButton.addEventListener("click", function() {
            window.location.href = "finalChat.html";
        });
    }

    window.addEventListener('scroll', function() {
        if (backgroundImage) {
            const scrollPosition = window.pageYOffset;
            backgroundImage.style.transform = 'translateY(' + scrollPosition * 0.5 + 'px)';
        }
        if (header) {
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        }
    });

    if (profileIcon && profileModal && modalMessage && modalYes && modalNo) {
        profileIcon.addEventListener('click', function() {
            if (isLoggedIn === true) {
                // User is logged in
                modalMessage.textContent = 'Would you like to view your account?';
                modalYes.onclick = function() {
                    window.location.href = 'crud.php';
                };
            } else {
                // User is not logged in
                modalMessage.textContent = 'Would you like to login?';
                modalYes.onclick = function() {
                    window.location.href = 'login.php';
                };
            }

            modalNo.onclick = function() {
                profileModal.style.display = 'none';
            };

            profileModal.style.display = 'block';
        });

        // Close modal when clicking outside
        window.addEventListener('click', function(event) {
            if (event.target == profileModal) {
                profileModal.style.display = 'none';
            }
        });
    } else {
        console.warn("One or more profile modal elements not found.");
    }
});