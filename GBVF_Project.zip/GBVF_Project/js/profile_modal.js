document.addEventListener('DOMContentLoaded', function() {
    const profileIcon = document.getElementById('profileIcon');
    const profileModal = document.getElementById('profileModal');
    const modalMessage = document.getElementById('modalMessage');
    const modalYes = document.getElementById('modalYes');
    const modalNo = document.getElementById('modalNo');

    if (profileIcon) {
        profileIcon.addEventListener('click', function() {
            if (isLoggedIn === true) {
                modalMessage.textContent = 'Would you like to view your account?';
                modalYes.onclick = function() {
                    window.location.href = 'crud.php';
                };
            } else {
                modalMessage.textContent = 'Would you like to login?';
                modalYes.onclick = function() {
                    window.location.href = 'login.php';
                };
            }

            modalNo.onclick = function() {
                profileModal.style.display = 'none';
            };

            profileModal.style.display = 'block';
        });
    }

    window.addEventListener('click', function(event) {
        if (event.target == profileModal) {
            profileModal.style.display = 'none';
        }
    });
});