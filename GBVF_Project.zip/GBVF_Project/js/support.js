document.addEventListener('DOMContentLoaded', function() {
    const currentPath = window.location.pathname;
    const currentPageFilename = currentPath.split('/').pop();

    const mainNavLinks = document.querySelectorAll('.main-nav-sticky ul li a');

    mainNavLinks.forEach(link => {
        const linkFilename = link.getAttribute('href').split('/').pop();

        link.classList.remove('active', 'active-page');
        link.removeAttribute('aria-current'); 

        if (linkFilename === currentPageFilename) {
            link.classList.add('active-page');
            link.setAttribute('aria-current', 'page'); 
        }
    });

    const bodyElement = document.body;
    let currentFontSize = parseFloat(getComputedStyle(bodyElement).fontSize);
    const defaultFontSize = currentFontSize;
    const fontSizeStep = 2;

    const highContrastToggle = document.getElementById('highContrastToggle');
    const increaseTextButton = document.getElementById('increaseText');
    const decreaseTextButton = document.getElementById('decreaseText');
    const resetTextButton = document.getElementById('resetText');

    if (highContrastToggle) {
        highContrastToggle.addEventListener('click', () => {
            bodyElement.classList.toggle('high-contrast');
        });
    }

    if (increaseTextButton) {
        increaseTextButton.addEventListener('click', () => {
            currentFontSize += fontSizeStep;
            bodyElement.style.fontSize = `${currentFontSize}px`;
        });
    }

    if (decreaseTextButton) {
        decreaseTextButton.addEventListener('click', () => {
            currentFontSize -= fontSizeStep;
            bodyElement.style.fontSize = `${currentFontSize}px`;
        });
    }

    if (resetTextButton) {
        resetTextButton.addEventListener('click', () => {
            currentFontSize = defaultFontSize;
            bodyElement.style.fontSize = `${defaultFontSize}px`;
            if (bodyElement.classList.contains('high-contrast')) {
                bodyElement.classList.remove('high-contrast'); 
            }
        });
    }

    const profileIcon = document.getElementById('profileIcon');
    const profileDropdown = document.getElementById('profileDropdown');

    if (profileIcon && profileDropdown) {
        profileIcon.addEventListener('click', (event) => {
            event.stopPropagation();
            profileDropdown.classList.toggle('show');
        });

        document.addEventListener('click', (event) => {
            if (!profileDropdown.contains(event.target) && !profileIcon.contains(event.target)) {
                profileDropdown.classList.remove('show');
            }
        });
    }


    let map;
    let userLocationMarker;
    let policeMarkers = L.featureGroup();
    let hospitalMarkers = L.featureGroup();
    let supportCenterMarkers = L.featureGroup();
    let currentLocation = null; 

    const policeIcon = L.icon({
        iconUrl: '../images/policeman.png',
        iconSize: [32, 32],
        iconAnchor: [16, 32],
        popupAnchor: [0, -32]
    });

    const hospitalIcon = L.icon({
        iconUrl: '../images/medicine.png',
        iconSize: [32, 32],
        iconAnchor: [16, 32],
        popupAnchor: [0, -32]
    });

    const supportCenterIcon = L.icon({
        iconUrl: '../images/support.png', 
        iconSize: [32, 32],
        iconAnchor: [16, 32],
        popupAnchor: [0, -32]
    });

    const defaultLocation = { lat: -26.2041, lng: 28.0473 };

    map = L.map('map').setView([defaultLocation.lat, defaultLocation.lng], 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '© <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    const serviceFilter = document.getElementById('serviceFilter');
    serviceFilter.addEventListener('change', () => {
        const selectedType = serviceFilter.value;
        if (currentLocation) { 
            findNearbyPlaces(currentLocation, policeIcon, hospitalIcon, supportCenterIcon, selectedType);
        }
    });

    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const lat = position.coords.latitude;
                const lng = position.coords.longitude;
                const pos = { lat: lat, lng: lng };
                currentLocation = pos;
                map.setView([lat, lng], 14);

                userLocationMarker = L.marker([lat, lng]).addTo(map)
                    .bindPopup("<b>Your Location</b>").openPopup();
                
                document.getElementById('loadingMessage').textContent = 'Services near your location:';
                findNearbyPlaces(currentLocation, policeIcon, hospitalIcon, supportCenterIcon, serviceFilter.value);
            },
            () => {
                currentLocation = defaultLocation;
                alert("Geolocation failed or denied. Displaying services near a default location in Johannesburg.");
                document.getElementById('loadingMessage').textContent = 'Services near default location in Johannesburg:';
                findNearbyPlaces(currentLocation, policeIcon, hospitalIcon, supportCenterIcon, serviceFilter.value);
            }
        );
    } else {
        currentLocation = defaultLocation;
        alert("Your browser doesn't support Geolocation. Displaying services near a default location in Johannesburg.");
        document.getElementById('loadingMessage').textContent = 'Services near default location in Johannesburg:';
        findNearbyPlaces(currentLocation, policeIcon, hospitalIcon, supportCenterIcon, serviceFilter.value);
    }

    const locationSearchInput = document.getElementById('locationSearchInput');
    const searchLocationButton = document.getElementById('searchLocationButton');

    if (searchLocationButton && locationSearchInput) {
        searchLocationButton.addEventListener('click', async () => {
            const address = locationSearchInput.value.trim();
            if (address) {
                document.getElementById('loadingMessage').textContent = 'Searching for services around ' + address + '...';
                const newLocation = await geocodeAddress(address);
                if (newLocation) {
                    currentLocation = newLocation; 
                    map.setView([newLocation.lat, newLocation.lng], 13); 
                    if (userLocationMarker) {
                        map.removeLayer(userLocationMarker);
                    }
                    userLocationMarker = L.marker([newLocation.lat, newLocation.lng]).addTo(map)
                        .bindPopup(`<b>Searched Location:</b> ${address}`).openPopup();
                    
                    const serviceFilter = document.getElementById('serviceFilter');
                    findNearbyPlaces(currentLocation, policeIcon, hospitalIcon, supportCenterIcon, serviceFilter.value);
                } else {
                    alert("Could not find location for '" + address + "'. Please try a different address.");
                    document.getElementById('loadingMessage').textContent = 'Loading services near your location:';
                }
            } else {
                alert("Please enter an address or city to search.");
            }
        });
    }

    async function geocodeAddress(address) {
        const nominatimUrl = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(address)}&format=json&limit=1&countrycodes=ZA`;
        try {
            const response = await fetch(nominatimUrl, {
                headers: {
                    'User-Agent': 'GBVSupportApp/1.0 (your-email@example.com)'
                }
            });
            const data = await response.json();
            if (data && data.length > 0) {
                return { lat: parseFloat(data[0].lat), lng: parseFloat(data[0].lon) };
            }
        } catch (error) {
            console.error("Geocoding failed:", error);
        }
        return null;
    }

    async function findNearbyPlaces(location, policeIcon, hospitalIcon, supportCenterIcon, filterType = 'all') {
        const overpassApiUrl = 'https://overpass-api.de/api/interpreter';
        const radius = 5000; 

        policeMarkers.clearLayers();
        hospitalMarkers.clearLayers();
        supportCenterMarkers.clearLayers();

        const commonQueryPart = (type) => `
            [out:json][timeout:25];
            (
                node["amenity"="${type}"](around:${radius},${location.lat},${location.lng});
                way["amenity"="${type}"](around:${radius},${location.lat},${location.lng});
                relation["amenity"="${type}"](around:${radius},${location.lat},${location.lng});
            );
            out center;
        `;

        const supportCenterQuery = `
            [out:json][timeout:25];
            (
                node["amenity"="social_facility"]["social_facility"="shelter"](around:${radius},${location.lat},${location.lng});
                way["amenity"="social_facility"]["social_facility"="shelter"](around:${radius},${location.lat},${location.lng});
                relation["amenity"="social_facility"]["social_facility"="shelter"](around:${radius},${location.lat},${location.lng});

                node["amenity"="social_facility"]["social_facility"="counselling"](around:${radius},${location.lat},${location.lng});
                way["amenity"="social_facility"]["social_facility"="counselling"](around:${radius},${location.lat},${location.lng});
                relation["amenity"="social_facility"]["social_facility"="counselling"](around:${radius},${location.lat},${location.lng});

                node["amenity"="community_centre"](around:${radius},${location.lat},${location.lng});
                way["amenity"="community_centre"](around:${radius},${location.lat},${location.lng});
                relation["amenity"="community_centre"](around:${radius},${location.lat},${location.lng});
            );
            out center;
        `;

        try {
            if (filterType === 'all' || filterType === 'police') {
                const policeResponse = await fetch(overpassApiUrl, { method: 'POST', body: commonQueryPart('police') });
                const policeData = await policeResponse.json();
                processOverpassData(policeData, 'police', policeIcon, hospitalIcon, supportCenterIcon);
            }

            if (filterType === 'all' || filterType === 'hospital') {
                const hospitalResponse = await fetch(overpassApiUrl, { method: 'POST', body: commonQueryPart('hospital') });
                const hospitalData = await hospitalResponse.json();
                processOverpassData(hospitalData, 'hospital', policeIcon, hospitalIcon, supportCenterIcon);
            }

            if (filterType === 'all' || filterType === 'support_centers') {
                const supportResponse = await fetch(overpassApiUrl, { method: 'POST', body: supportCenterQuery });
                const supportData = await supportResponse.json();
                processOverpassData(supportData, 'support_centers', policeIcon, hospitalIcon, supportCenterIcon);
            }

        } catch (error) {
            console.error("Error fetching Overpass API data:", error);
            alert("Could not load nearby services. Please check your internet connection and try again.");
        } finally {
            if (!map.hasLayer(policeMarkers)) map.addLayer(policeMarkers);
            if (!map.hasLayer(hospitalMarkers)) map.addLayer(hospitalMarkers);
            if (!map.hasLayer(supportCenterMarkers)) map.addLayer(supportCenterMarkers);
        }
    }

    function processOverpassData(data, type, policeIcon, hospitalIcon, supportCenterIcon) {
        data.elements.forEach(element => {
            const lat = element.lat || (element.center && element.center.lat);
            const lng = element.lon || (element.center && element.center.lon);

            if (lat && lng) {
                const name = element.tags.name || `Unnamed ${type.charAt(0).toUpperCase() + type.slice(1)}`;
                const address = element.tags['addr:full'] || element.tags['addr:street'] || (element.tags['addr:housenumber'] ? `${element.tags['addr:housenumber']} ${element.tags['addr:street']}` : 'Address unknown');
                const phone = element.tags.phone || element.tags['contact:phone'] || 'N/A';
                const website = element.tags.website || element.tags.url || element.tags['contact:website'] || '';
                const openingHours = element.tags.opening_hours || 'Not specified';
                const operator = element.tags.operator || '';
                const description = element.tags.description || '';
                const contactEmail = element.tags.email || element.tags['contact:email'] || '';

                let marker;
                if (type === 'police') {
                    marker = L.marker([lat, lng], { icon: policeIcon }).addTo(policeMarkers);
                } else if (type === 'hospital') {
                    marker = L.marker([lat, lng], { icon: hospitalIcon }).addTo(hospitalMarkers);
                } else if (type === 'support_centers') {
                    marker = L.marker([lat, lng], { icon: supportCenterIcon }).addTo(supportCenterMarkers);
                }

                let popupContent = `
                    <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
                        <h3 style="margin-bottom: 5px; color: #4B164C;">${name}</h3>
                        <p style="margin-bottom: 3px;"><strong>Address:</strong> ${address}</p>
                        <p style="margin-bottom: 3px;"><strong>Phone:</strong> ${phone}</p>
                `;

                if (website && website !== '') {
                    popupContent += `<p style="margin-bottom: 3px;"><strong>Website:</strong> <a href="${website}" target="_blank">${website}</a></p>`;
                }
                if (contactEmail && contactEmail !== '') {
                    popupContent += `<p style="margin-bottom: 3px;"><strong>Email:</strong> <a href="mailto:${contactEmail}">${contactEmail}</a></p>`;
                }
                if (openingHours && openingHours !== 'Not specified') {
                    popupContent += `<p style="margin-bottom: 3px;"><strong>Hours:</strong> ${openingHours}</p>`;
                }
                if (operator && operator !== '') {
                    popupContent += `<p style="margin-bottom: 3px;"><strong>Operator:</strong> ${operator}</p>`;
                }
                if (description && description !== '') {
                    popupContent += `<p style="margin-bottom: 3px;"><strong>Description:</strong> ${description}</p>`;
                }

                if (currentLocation) { 
                    const originLat = currentLocation.lat;
                    const originLng = currentLocation.lng;
                    const destinationLat = lat;
                    const destinationLng = lng;

                    const googleMapsDirectionsUrl = `https://www.google.com/maps/dir/?api=1&origin=${originLat},${originLng}&destination=${destinationLat},${destinationLng}&travelmode=driving`;
                    
                    popupContent += `<p style="margin-top: 10px;"><a href="${googleMapsDirectionsUrl}" target="_blank" style="background-color: #4B164C; color: white; padding: 8px 15px; border-radius: 5px; text-decoration: none; font-weight: bold; display: inline-block;">Get Directions</a></p>`;
                }

                popupContent += `</div>`;

                marker.bindPopup(popupContent);
            }
        });
    }

    window.addEventListener('scroll', () => {
        const scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
        const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
        const scrolled = (scrollTop / scrollHeight) * 100;
        document.querySelector('.scroll-progress').style.width = scrolled + '%';
    });
});
