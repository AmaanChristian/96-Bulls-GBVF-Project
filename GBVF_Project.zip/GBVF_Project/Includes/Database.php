<?php
    $host = 'localhost';
    $dbname = 'registration_db';
    $user = 'root';
    $password = '';

$conn = new mysqli($host,$user,$password, $dbname);

if($conn->connect_error){
    die("connection failed:" . $conn->connect_error);
}
?>