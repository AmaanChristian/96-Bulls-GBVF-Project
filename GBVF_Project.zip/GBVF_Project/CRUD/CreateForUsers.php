
<?php
include 'Database.php';

// Function to sanitize input
function sanitize_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize inputs
    $name = sanitize_input($_POST['name']);
    $surname = sanitize_input($_POST['surname']);
    $username = sanitize_input($_POST['username']);
    $email = sanitize_input($_POST['email']);
    $phone = sanitize_input($_POST['phone']);
    $address = sanitize_input($_POST['address']);
    $password = sanitize_input($_POST['password']);

    // Validate inputs
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email format.");
    }

    if (!is_numeric($phone) || strlen($phone) < 10) {
        die("Invalid phone number.");
    }

    if (strlen($password) < 6) {
        die("Password must be at least 6 characters.");
    }

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Use prepared statements
    $stmt = $conn->prepare("INSERT INTO users (name, surname, username, email, phone, address, password) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $name, $surname, $username, $email, $phone, $address, $hashed_password);

    if ($stmt->execute()) {
        header('Location: InitialPage.php');
        exit;
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
