
<?php
include 'Database.php';

// Function to sanitize input
function sanitize_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize inputs
    $contact_name = sanitize_input($_POST['contact_name']);
    $relationship = sanitize_input($_POST['relationship']);
    $contact_phone = sanitize_input($_POST['contact_phone']);

    // Validate phone number
    if (!is_numeric($contact_phone) || strlen($contact_phone) < 10) {
        die("Invalid contact phone number.");
    }

    // Use prepared statement
    $stmt = $conn->prepare("INSERT INTO emergency_contacts (contact_name, relationship, contact_phone) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $contact_name, $relationship, $contact_phone);

    if ($stmt->execute()) {
        header('Location: InitialPage.php');
        exit;
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
