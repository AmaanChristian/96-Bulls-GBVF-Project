<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title data-translate="page-title-registration">User Registration & Emergency Contacts</title>
    <link rel="stylesheet" href="Styling.css"> </head>
<body>
    <div class="language-selector-fixed">
        <select id="languageSelect" aria-label="Select Language">
            <option value="en">English</option>
            <option value="af">Afrikaans</option>
            <option value="nso">Sepedi</option>
            <option value="st">Sesotho</option>
            <option value="ss">Siswati</option>
            <option value="tn">Setswana</option>
            <option value="ts">Xitsonga</option>
            <option value="ve">Tshivenḓa</option>
            <option value="xh">isiXhosa</option>
            <option value="zu">isiZulu</option>
            <option value="nr">isiNdebele</option>
        </select>
    </div>

    <nav class="main-nav-sticky">
        <ul>
            <li><a href="home.php" data-translate="nav-home">Home</a></li>
            <li><a href="InitialPage.php" class="active-page" data-translate="nav-registration">Registration</a></li>
            <li><a href="legal.html" data-translate="nav-resources">Resources</a></li>
            <li><a href="support.html" data-translate="nav-support">Support</a></li>
            <li><a href="gbv.html" data-translate="nav-gbv">GBV</a></li>
            <li><a href="finalChat.html" data-translate="nav-safe-haven">Safe Haven</a></li>
            <li><a href="share.html" data-translate="nav-share-story">Share Your Story</a></li>
            <li><a href="Contact.html" data-translate="nav-contact-us">Contact Us</a></li>
        </ul>
    </nav>

    <header>
        <h1 data-translate="registration-header-title">User Registration & Emergency Contacts</h1>
        <p data-translate="registration-header-description">Secure registration system for users and emergency contact management</p>
    </header>

    <div class="emergency-banner">
        <h3 data-translate="emergency-banner-title">Emergency Help</h3>
        <p data-translate="emergency-banner-description">If you are in immediate danger, call the police at <strong>10111</strong> or the Gender-Based Violence Command Centre at <strong>0800 428 428</strong>.</p>
    </div>

    <section class="section" id="user-registration">
        <h2 data-translate="user-registration-title">User Registration</h2>
        
        <div class="form-container">
            <form action="CreateForUsers.php" method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label for="name">First Name</label>
                        <input type="text" id="name" name="name" required pattern="[A-Za-z\s]+" title="Only letters and spaces allowed">
                    </div>
                    <div class="form-group">
                        <label for="surname">Last Name</label>
                        <input type="text" id="surname" name="surname" required pattern="[A-Za-z\s]+" title="Only letters and spaces allowed">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" id="username" name="username" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="phone">Phone Number</label>
                        <input type="tel" id="phone" name="phone" required pattern="\d{10,13}" title="10-13 digits only">
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" required minlength="6" title="Minimum 6 characters">
                    </div>
                </div>
                
                <div class="form-group full-width">
                    <label for="address">Address</label>
                    <textarea id="address" name="address" required rows="3"></textarea>
                </div>
                
                <button type="submit">Register User</button>
            </form>
        </div>

        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    include 'Database.php';
                    $sql = "SELECT * FROM users";
                    $result = $conn->query($sql);

                    if($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>". htmlspecialchars($row['id'])."</td>";
                            echo "<td>". htmlspecialchars($row['name'])."</td>";
                            echo "<td>". htmlspecialchars($row['surname'])."</td>";
                            echo "<td>". htmlspecialchars($row['username'])."</td>";
                            echo "<td>". htmlspecialchars($row['email'])."</td>";
                            echo "<td>". htmlspecialchars($row['phone'])."</td>";
                            echo "<td class='action-links'>";
                            echo "<a href='EditForUsers.php?id=".$row['id'] . "' class='edit'>Edit</a>";
                            echo "<a href='DeleteForUsers.php?id=" . $row['id'] ."' class='delete' onclick='return confirm(\"Are you sure you want to delete this user?\")'>Delete</a>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='7' class='no-data'>No users found. Register your first user above!</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </section>

    <section class="section" id="emergency-contacts">
        <h2 data-translate="emergency-contacts-title">Emergency Contacts</h2>
        
        <div class="form-container">
            <form action="CreateForEmergency.php" method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label for="contact_name">Contact Name</label>
                        <input type="text" id="contact_name" name="contact_name" required>
                    </div>
                    <div class="form-group">
                        <label for="relationship">Relationship</label>
                        <input type="text" id="relationship" name="relationship" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="contact_phone">Contact Phone Number</label>
                    <input type="tel" id="contact_phone" name="contact_phone" required pattern="\d{10,13}" title="10-13 digits only">
                </div>
                
                <button type="submit">Add Emergency Contact</button>
            </form>
        </div>

        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Contact Name</th>
                        <th>Relationship</th>
                        <th>Phone Number</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT * FROM emergency_contacts";
                    $result = $conn->query($sql);

                    if($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>". htmlspecialchars($row['id'])."</td>";
                            echo "<td>". htmlspecialchars($row['contact_name'])."</td>";
                            echo "<td>". htmlspecialchars($row['relationship'])."</td>";
                            echo "<td>". htmlspecialchars($row['contact_phone'])."</td>";
                            echo "<td class='action-links'>";
                            echo "<a href='EditForEmergency.php?id=".$row['id'] . "' class='edit'>Edit</a>";
                            echo "<a href='DeleteForEmergency.php?id=" . $row['id'] ."' class='delete' onclick='return confirm(\"Are you sure you want to delete this emergency contact?\")'>Delete</a>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5' class='no-data'>No emergency contacts found. Add your first contact above!</td></tr>";
                    }
                    
                    $conn->close();
                    ?>
                </tbody>
            </table>
        </div>
    </section>

    <footer>
        <p data-translate="footer-registration-info">This registration system helps manage user accounts and emergency contacts securely.</p>
        <p data-translate="footer-disclaimer">All personal information is handled according to privacy regulations and best practices.</p>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const deleteLinks = document.querySelectorAll('a.delete');
            deleteLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    if (!confirm('Are you sure you want to delete this record? This action cannot be undone.')) {
                        e.preventDefault();
                    }
                });
            });

            const currentPath = window.location.pathname;
            const currentPageFilename = currentPath.split('/').pop();
            const mainNavLinks = document.querySelectorAll('.main-nav-sticky ul li a');

            mainNavLinks.forEach(link => {
                const linkFilename = link.getAttribute('href').split('/').pop();
                link.classList.remove('active', 'active-page');
                link.removeAttribute('aria-current'); 

                if (linkFilename === currentPageFilename) {
                    link.classList.add('active-page');
                    link.setAttribute('aria-current', 'page'); 
                }
            });

            const forms = document.querySelectorAll('form');
            forms.forEach(form => {
                form.addEventListener('submit', function(e) {
                    const requiredFields = form.querySelectorAll('[required]');
                    let hasErrors = false;

                    requiredFields.forEach(field => {
                        if (!field.value.trim()) {
                            hasErrors = true;
                            field.style.borderColor = '#dc3545';
                        } else {
                            field.style.borderColor = 'rgb(221, 136, 207)';
                        }
                    });

                    if (hasErrors) {
                        e.preventDefault();
                        alert('Please fill in all required fields.');
                    }
                });
            });
        });
    </script>
</body>
</html>