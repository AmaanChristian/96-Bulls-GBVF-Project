<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Emergency Contact</title>
    <link href="Styling.css" rel="stylesheet">
</head>
<body>

<?php
include 'Database.php';

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];

    // Use prepared statement to fetch emergency contact
    $stmt = $conn->prepare("SELECT * FROM emergency_contacts WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "Emergency contact not found.";
        exit;
    }

    $stmt->close();
} else {
    echo "Invalid ID.";
    exit;
}

function escape($value) {
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}
?>

<form action="Update.php" method="POST">
    <input type="hidden" name="id" value="<?php echo escape($row['id']); ?>">
    <label>CONTACT NAME:</label>
    <input type="text" name="contact_name" value="<?php echo escape($row['contact_name']); ?>" required><br><br>
    <label>RELATIONSHIP:</label>
    <input type="text" name="relationship" value="<?php echo escape($row['relationship']); ?>" required><br><br>
    <label>CONTACT PHONE NUMBER:</label>
    <input type="text" name="contact_phone" value="<?php echo escape($row['contact_phone']); ?>" required><br><br>

    <button type="submit">UPDATE EMERGENCY CONTACT</button>
</form>

</body>
</html>
