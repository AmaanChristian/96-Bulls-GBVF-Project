<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update</title>
    <link href="style.css" rel="stylesheet">
</head>
<body>
    
<?php
include 'Database.php';

// Helper function to sanitize string inputs
function clean_input($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // USER update block
    if (
        isset($_POST['name'], $_POST['surname'], $_POST['username'], $_POST['email'], $_POST['phone'], $_POST['address'], $_POST['password'], $_POST['id'])
    ) {
        $id = intval($_POST['id']);
        $name = clean_input($_POST['name']);
        $surname = clean_input($_POST['surname']);
        $username = clean_input($_POST['username']);
        $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
        $phone = clean_input($_POST['phone']);
        $address = clean_input($_POST['address']);
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

        if ($email === false) {
            echo "Invalid email format.";
            exit;
        }

        $stmt = $conn->prepare("UPDATE users SET name=?, surname=?, username=?, email=?, phone=?, address=?, password=? WHERE id=?");
        $stmt->bind_param("sssssssi", $name, $surname, $username, $email, $phone, $address, $password, $id);

        if ($stmt->execute()) {
            header('Location: InitialPage.php');
            exit;
        } else {
            echo "Error updating user: " . $stmt->error;
        }

        $stmt->close();
    }

    // EMERGENCY CONTACT update block
    elseif (
        isset($_POST['contact_name'], $_POST['relationship'], $_POST['contact_phone'], $_POST['id'])
    ) {
        $id = intval($_POST['id']);
        $contact_name = clean_input($_POST['contact_name']);
        $relationship = clean_input($_POST['relationship']);
        $contact_phone = clean_input($_POST['contact_phone']);

        $stmt = $conn->prepare("UPDATE emergency_contacts SET contact_name=?, relationship=?, contact_phone=? WHERE id=?");
        $stmt->bind_param("sssi", $contact_name, $relationship, $contact_phone, $id);

        if ($stmt->execute()) {
            header('Location: InitialPage.php');
            exit;
        } else {
            echo "Error updating emergency contact: " . $stmt->error;
        }

        $stmt->close();
    }

    else {
        echo "Invalid form submission.";
    }

    $conn->close();
}
?>


</body>
</html>

